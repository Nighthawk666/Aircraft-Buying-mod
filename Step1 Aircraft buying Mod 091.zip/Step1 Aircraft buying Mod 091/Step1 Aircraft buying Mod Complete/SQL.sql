alter table `phpvms_aircraft` add column `price` varchar(15) NOT NULL DEFAULT '0';
alter table `phpvms_aircraft` add column `cond` varchar(15) NOT NULL DEFAULT '0';
alter table `phpvms_aircraft` add column `bought` varchar(15) NOT NULL DEFAULT '0';
alter table `phpvms_aircraft` add column `rep` varchar(15) NOT NULL DEFAULT '0';
alter table `phpvms_aircraft` add column `maint` varchar(15) NOT NULL DEFAULT '0';
alter table `phpvms_aircraft` add column `rmtime` varchar(15) NOT NULL DEFAULT '0';